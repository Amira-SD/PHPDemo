<?php
echo '<div id="footerwrap">
<footer id="mainfooter" class="bodywidth clear">
    <div class="asiakaspalvelu">
      <p><b  class="titlefooter">Support</b><br>
      <a  class="data" href="mailto:support@webhotel.com">support@webhotel.com</a><br>
      <a class="data" > phone 01234567 </a><p>
          </div>
              <div class="asiakaspalvelu">
     <p><b class="titlefooter">Sales</b> <br>
          <a class="data" href="mailto:sales@webhotel.com">sales@webhotel.com</a><br>
         <a class="data" > phone 01234567 </a><p>
          </div>
          <div id="socialmedia">
      <a href="https://www.facebook.com/">
          <img src="images/fb.png" alt="Facebook" 
        >
      </a>  
      <a href="https://www.youtube.com/">
          <img src="images/youtube.png" alt="Youtube" 
      >
      </a>   
      <a href="https://www.instagram.com/">
          <img src="images/IG.png" alt="instagram" 
          >
      </a> </div>  
  </footer>
</div>';
?>