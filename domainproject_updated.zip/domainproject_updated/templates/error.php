<?php
echo '
<img style="  width: 100%;" src="./images/error.png"> 
';
?>